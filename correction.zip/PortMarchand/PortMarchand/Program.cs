﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PortMarchand
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Navire unNavire = new Navire("666", "CorsicaMehdi", "Plante", 8000);
                //Port ListeDePort = new Port("");

                Port unPort = new Port();
                // On va rajouter quelques stockages dans le port

                unPort.AjouterStockage(1000);
                unPort.AjouterStockage(2000);
                unPort.AjouterStockage(1500);
                unPort.AjouterStockage(2500);
                //unNavire.Decharger(-5000);
                unPort.AjouterStockage(-500);

                unPort.dechargement(unNavire);

                if(unNavire.EstDecharge()) {
                    Console.WriteLine("Le navire est déchargé");
                }
                
            }

            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();
        }
    }
}
