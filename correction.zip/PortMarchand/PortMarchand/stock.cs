﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PortMarchand
{
    class stock
    {
        private int capaDispo;

        public stock(int pQte)
        {
            this.capaDispo = pQte;
        }

        public int obtenirCapaDispo()
        {
            return this.capaDispo;
        }

        public void stocker(int qte)
        {
            this.capaDispo = this.capaDispo - qte;

        }
    }
}
