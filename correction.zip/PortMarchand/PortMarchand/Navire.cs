﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PortMarchand
{
    class Navire
    {
        private string nbNav;
        private string nomNav;
        private string libelleFret;
        private int quantiteFret;
        

        //Constructeur
        public Navire (string pnbNav,string pnomNav,string plibelleFret,int pquantiteFret)
        {
            this.nbNav = pnbNav;
            this.nomNav = pnbNav;
            this.libelleFret = plibelleFret;
            this.quantiteFret = pquantiteFret;
        }

        //surcharge du constructeur parce que j'en ai besoin dans stock
        public Navire()
        {
        }

        public int ObtenirQteFret()
        {
            return quantiteFret;
        }
        
        public bool EstDecharge()
        {
            if (quantiteFret == 0)
            {
                return true;

            }
            else
            {
                return false;
            }
        }

    

        public void Decharger (int quantite)
        {
            if (quantite <= this.quantiteFret && quantite >= 0)
            {
                this.quantiteFret = this.quantiteFret - quantite;

            }
            else
            {
                throw new Exception("Impossible de decharger");

            }

        }










    }
}
