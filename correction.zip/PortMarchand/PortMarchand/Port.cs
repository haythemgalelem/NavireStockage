﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace PortMarchand
{
    class Port
    {
        private List<stock> stockage;
        

        //constructeur qui construit de façon improvisé aussi
        //mais faut rendre l'algo pour demain...
        public Port()
        {
            this.stockage = new List<stock>();
    
        }

        public void AjouterStockage(int capacite)
        {
            if(capacite >= 0)
            {
                stockage.Add(new stock(capacite));
            } else
            {
                throw new Exception("Ajout d'un stockage impossible. ");
            }
        }


        public void dechargement(Navire unNavire)
        {
            int i = 0;

            while (!unNavire.EstDecharge() && i < this.stockage.Count)
            {
                if (stockage.ElementAt(i).obtenirCapaDispo()>0) 
                {
                    //on peut stoker dans le stokage
                    if (stockage.ElementAt(i).obtenirCapaDispo() < unNavire.ObtenirQteFret())
                        //Je ne peux pas décharger tout le navire
                        //On va décharger du navire ce que l'on peut stocker dans le stockage
                    {
                        unNavire.Decharger(stockage.ElementAt(i).obtenirCapaDispo());
                        this.stockage.ElementAt(i).stocker(this.stockage.ElementAt(i).obtenirCapaDispo());
                    }
                    else
                    //il y a suffisament de capacité dispo dans le stockage pour stocker tout ce qu'il reste dans le navire
                    {
                        this.stockage.ElementAt(i).stocker(unNavire.ObtenirQteFret());
                        unNavire.Decharger(unNavire.ObtenirQteFret());
                    }
                }

                i = i + 1;
            }
            if(!unNavire.EstDecharge())
            {
                throw new Exception("Le navire n'a pas pu être déchargé");
            }

        }

    }
}
